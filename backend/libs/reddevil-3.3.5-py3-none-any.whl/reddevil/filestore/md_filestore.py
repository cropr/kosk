# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2023

# all models in the service level exposed to the API
# we are using pydantic as tool

import logging

from reddevil.core import DbBase
from datetime import datetime, date, timezone
from typing import Dict, Any, List, Optional, Type
from fastapi import File
from pydantic import BaseModel, Field


class FileIn(BaseModel):
    """
    contains the minimal fields (doctype and name) to create a new page
    """

    group: str
    content: bytes
    name: str
    metadata: Dict | None
